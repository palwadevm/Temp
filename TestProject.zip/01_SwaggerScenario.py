import csv
import json
from itertools import product
from datetime import datetime
from flask import Flask, request
from flask_restful import Resource, Api
from flask import Flask, jsonify
from flask_swagger_ui import get_swaggerui_blueprint

DATA_SOURCE = 'data_combinations.csv'

app = Flask(__name__)
api = Api(app)
# Define Swagger UI configuration
SWAGGER_URL = '/swagger'
API_URL = '/static/swagger.json'  # path to the Swagger JSON file

# Create a blueprint for Swagger UI
swaggerui_blueprint = get_swaggerui_blueprint(
    SWAGGER_URL,
    API_URL,
    config={
        'app_name': "Swagger Data Utils"
    }
)
# Register the blueprint with the Flask application
app.register_blueprint(swaggerui_blueprint, url_prefix=SWAGGER_URL)


# Read Records By Id
def read_records_by_id(csv_file, id):
    records = {}
    with open(csv_file, 'r', newline='') as file:
        reader = csv.DictReader(file)
        for row in reader:
            record_id = int(row['id'])
            if id == record_id:
                if record_id not in records:
                    records[record_id] = []
                records[record_id].append(row)
    if records == {}:
        return []
    else:
        return [rec for rec in records[id]]


# Define some sample API endpoints
@app.route('/records/<int:id>', methods=['GET'])
def get_record(id):
    print("Get Request - " + str(id))
    if not isinstance(id, int):
        return jsonify({'error': 'Id should be int value between 0-99999'}), 400
    if id < 0 or id >= 99999:
        return jsonify({'error': 'Id should be int value between 0-99999'}), 400
    records = read_records_by_id(DATA_SOURCE, id)
    return json.dumps(records)


@app.route('/records', methods=['POST'])
def sample_post():
    print("Post Request")
    json_data = request.get_json()
    writerow_ToCSV(DATA_SOURCE, json_data)
    return jsonify({"message": "This is another sample API endpoint"})


# Function to generate data combinations
def generate_data_combinations():
    id_values = range(10000, 20000, 10000)  # Numeric values from 1 to 99
    first_names = ['John', 'Alice', 'Bob', 'Emma']
    last_names = ['Doe', 'Smith', 'Johnson', 'Brown']
    ages = range(20, 30, 5)  # Ages from 18 to 99
    salaries = range(30000, 50000, 10000)  # Salary range
    experiences = [round(x * 0.5, 2) for x in range(3, 5)]  # Floats with one decimal place
    # Current date in mmddyyyy format
    dates_of_joining = [datetime.strftime(datetime.now(), "%m%d%Y") for _ in range(10)]

    # Generate all possible combinations
    combinations = product(id_values, first_names, last_names, ages, salaries, experiences, dates_of_joining)
    return combinations


# Function to write data combinations to CSV
def write_to_csv(filename, data):
    with open(filename, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['id', 'first-name', 'last-name', 'age', 'salary', 'experience', 'date-of-joining'])
        writer.writerows(data)


def writerow_ToCSV(filename, data):
    line = []
    line.append(data['id'])
    cols = ['first-name', 'last-name', 'age', 'salary', 'experience', 'date-of-joining']
    for col in cols:
        line.append(str(data[col] if col in data else ''))
    # Open the CSV file in append mode
    with open(filename, 'a', newline='') as csvfile:
        # Create a CSV writer object
        csv_writer = csv.writer(csvfile)
        # Write the new line
        csv_writer.writerow(line)


# Generate data combinations
data_combinations = generate_data_combinations()

# Write data combinations to CSV
write_to_csv('data_combinations.csv', data_combinations)

if __name__ == '__main__':
    app.run(debug=True)
