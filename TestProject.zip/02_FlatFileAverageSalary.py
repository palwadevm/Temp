from datetime import datetime


# Function to parse a line from the fixed length flat file
def parse_line(line):
    return {
        'id': int(line[0:5]),
        'firstname': line[5:55].strip(),
        'lastname': line[55:105].strip(),
        'age': int(line[105:108]),
        'salary': int(line[108:114]),
        'date': datetime.strptime(line[114:122], '%Y%m%d').date()
    }


# Function to calculate average salary and number of days in office for each employee_data.txt
def calculate_avg_salary_and_days(file_path):
    employee_data = {}

    with open(file_path, 'r') as file:
        for line in file:
            if len(line.strip()) != 0:  # Check for empty lines
                record = parse_line(line)
                key = (record['id'], record['firstname'], record['lastname'])
                if key not in employee_data:
                    employee_data[key] = {'salary_total': 0, 'days_in_office': 0, 'count': 0}
                    employee_data[key]['days_in_office'] = datetime.today().date()
                employee_data[key]['salary_total'] += record['salary']
                employee_data[key]['days_in_office'] = record['date'] if record['date'] < employee_data[key][
                    'days_in_office'] else employee_data[key]['days_in_office']
                employee_data[key]['count'] += 1

    # Calculate average salary and number of days for each employee_data.txt
    avg_salary_and_days = {}
    for key, data in employee_data.items():
        avg_salary_and_days[key] = {
            'avg_salary': data['salary_total'] / data['count'],
            'days_in_office': (datetime.today().date() - data['days_in_office']).days
        }

    return avg_salary_and_days


# Function to write the output to a file
def write_output(output_file, avg_salary_and_days):
    with open(output_file, 'w') as file:
        file.write("id,firstname,lastname,age,average_salary,number_of_days_in_office\n")
        for key, data in avg_salary_and_days.items():
            id, firstname, lastname = key
            avg_salary = data['avg_salary']
            days_in_office = data['days_in_office']
            file.write(f"{id},{firstname},{lastname},{avg_salary:.2f},{days_in_office}\n")


# Example usage
file_path = 'employee_data.txt'  # Replace with your file path
output_file = 'output.csv'  # Output file path

avg_salary_and_days = calculate_avg_salary_and_days(file_path)
write_output(output_file, avg_salary_and_days)
